import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class ListaDeTarefasGUI extends JFrame {

    private JPanel painel = new JPanel();
    private JButton jButtonadicionarTarefa = new JButton("Adicione uma Tarefa");
    private JButton jButtonremoverTarefa = new JButton("Remova uma Tarefa");
    private JButton jButtonlistarTarefas = new JButton("Listar Tarefas");

    public ListaDeTarefasGUI(){
        this.setTitle("== Lista De Tarefas - Interface Gráfica ==");
        this.setSize(400,200);
        painel.setLayout(new FlowLayout(FlowLayout.CENTER, 100, 20));
        painel.setBackground(new Color(255, 255, 255));
        ArrayList<String> Tarefas = new ArrayList<String>();

        jButtonadicionarTarefa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Tarefa = JOptionPane.showInputDialog(null,"Digite uma tarefa para ser adicionada: ");
                Tarefas.add(Tarefa);
            }
        });

        jButtonremoverTarefa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String indice1 = JOptionPane.showInputDialog(null, "Digite o número referente a tarefa que deseja remover (A lista começa pelo número 0)\n As tarefas são: " + Tarefas);
                int indice = Integer.parseInt(indice1);
                Tarefas.remove(indice);
            }
        });

        jButtonlistarTarefas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "As tarefas são: " + Tarefas);
            }
        });

        painel.add(jButtonadicionarTarefa);
        painel.add(jButtonremoverTarefa);
        painel.add(jButtonlistarTarefas);

        this.getContentPane().add(painel);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    public static void main(String[] args) {new ListaDeTarefasGUI();}


}